package ch06.sec11.exam02;

public class Earth {
    int radius = 64000;
    static double pi = 3.14159;

    public double result() {
        return 4 * pi * radius * radius;
    }
}
