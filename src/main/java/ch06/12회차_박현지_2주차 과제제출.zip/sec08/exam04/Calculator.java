package ch06.sec08.exam04;

public class Calculator
{
    public double areaRectangle(int a)
    {
        return a*a;
    }
    public double areaRectangle(int a,int b)
    {
        return a*b;
    }

}
