package ch06.sec09;

public class CarExample
{
    public static void main(String[] args)
    {
        Car myCar = new Car("코나");
        myCar.setSpeed(100);
        myCar.run();
    }
}
