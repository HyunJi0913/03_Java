package ch12.sec04;
import java.util.Properties;
import java.util.Set;
public class GetPropertyExample {
    public static void main(String[] args) {
    }
}