package ch12.sec03.exam03;

public record Member(String id, String name, int age) {
}
